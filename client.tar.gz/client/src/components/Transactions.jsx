const Transactions = () => {
  return (
    <h1>Transactions</h1>
  );
};

export default Transactions;
