const Services = () => {
  return (
    <h1>Services</h1>
  );
};

export default Services;
